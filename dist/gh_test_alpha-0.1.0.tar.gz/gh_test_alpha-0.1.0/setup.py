# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['greet']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['greet = greet.main:cli']}

setup_kwargs = {
    'name': 'gh-test-alpha',
    'version': '0.1.0',
    'description': '',
    'long_description': '# gh-test-alpha',
    'author': 'Jason Roark',
    'author_email': 'roarkj2@vcu.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
