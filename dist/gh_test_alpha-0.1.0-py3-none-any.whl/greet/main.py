


def cli():
    print("Hello world from greet")